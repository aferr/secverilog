#ifndef __controls_h
#define __controls_h

#include "vpi_user.h"

PLI_INT32 get_value(PLI_BYTE8 *unused);

#endif /* __controls_h */
